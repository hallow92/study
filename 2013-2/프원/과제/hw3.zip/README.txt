# Task 1 (hw3-1)

+ DO NOT ADD OTHER COMMENTS.
+ MODIFY ONLY "TODO"s in the following comments.
+ SUBMIT ONLY hw3-1.rkt

# Task 2 (hw3-2)

+ DO NOT RELY ON THE IMPLEMENTATION of hw3-2-library.rkt;
  USE JUST INTERFACES.
+ SUBMIT ONLY hw3-2.rkt
+ SELF-GRADE with hw3-2-grade.rkt before submission.

# Task 3 (hw3-3)

+ DO NOT RELY ON THE IMPLEMENTATION of hw3-3-library.rkt;
  USE JUST INTERFACES.
+ SUBMIT ONLY hw3-3.rkt
+ See hw3-3.ps to check if your answer is correct.
+ To see .ps files, download:
  - GhostScript: http://www.ghostscript.com/download/gsdnld.html
  - Ghostview: http://pages.cs.wisc.edu/~ghost/gsview/
