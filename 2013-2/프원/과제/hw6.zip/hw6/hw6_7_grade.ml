open CommonGrade
open Hw6_7

(* NOTE that this grader is not complete; any expression equivalent to 0 is OK.  Read the specification. *)
let _ = output (fun () ->
  crazy2add NIL NIL = NIL)

